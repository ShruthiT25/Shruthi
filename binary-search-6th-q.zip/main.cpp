#include <iostream>
using namespace std;
int frequency_count(int arr[], int num, int size){
   int count = 0;
   for(int i=0; i<size; i++){
      if(num==arr[i]){
         count++;
      }
   }
   return count;
}
int main(){
   int arr[] = {1, 1, 1,2, 3, 4};
   int num = 1;
   int size = sizeof(arr)/sizeof(arr[0]);
   cout<<"Count of number of occurrences (or frequency) in a sorted array are: "<<frequency_count(arr, num, size);
   return 0;
}