#include <bits/stdc++.h> 
using namespace std; 
    
int main() 
{ 
    int n;
    cin>>n;
    vector<int> v;
    for(int j=0;j<n;j++)
    {
        int p;
        cin>>p;
        v.push_back(p);
    }
    int l = 0;
    int r = n-1;
    int last = v[r];
    while(l<r) 
    {
        int mid=l+(r-l)/2;
        if(v[mid]>last) 
        {
            l=mid+1;
        } 
        else 
        {
            r=mid;
        }
    }
    cout<<v[l]<<endl;
  return 0; 
} 